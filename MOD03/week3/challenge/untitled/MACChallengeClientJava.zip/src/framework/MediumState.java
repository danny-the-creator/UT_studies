package framework;

/**
 * Medium states
 */
public enum MediumState {
    Idle, Collision, Succes
}

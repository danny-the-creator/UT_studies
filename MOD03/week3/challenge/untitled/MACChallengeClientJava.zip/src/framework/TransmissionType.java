package framework;

/**
 * Transmission instructions
 */
public enum TransmissionType {
    Silent, Data, NoData
}

package ss.week6.pizza;

/**
 * Pizza with pepperoni topping.
 */
public class Pizza {
    private int pepperoni = 0;

    //@ private invariant pepperoni >= 0;

    /**
     * Add pepperoni to the pizza.
     */
    //@ ensures pepperoni == \old(pepperoni) + 1;
    public void addPepperoni() {
        pepperoni += 1;
    }

    /**
     * Returns a textual representation of this pizza.
     * @return the textual representation
     */
    //@ pure;
    @Override
    public String toString() {
        return "pizza with " + pepperoni + " pepperoni";
    }
}

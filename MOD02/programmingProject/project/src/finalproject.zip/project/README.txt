This project is a software for running the dots and boxes game, either on server using the client or on it's own through the DnBTUI. 
To run the game tui (not on the server), you need to go to the game folder -> ui folder and run the BnDTUI main method. 
To run the server, go to the server package and run the server's main method and follow the instructions on the screen.
To run the client, go to the client package and run the clientTUI class's main method, we believe it is user-friendly enough to navigate through.
To see the testing results, go to the test folder and run both tests, plese mark the folder as "test" beforhand. Note that there is one test that only tests the game functionality
with DIM == 2! (there will be an appropriate comment, hopefully, DIM is 2 now by default)
Also, (applies to the DnBTUI game only), to test the functionality of the AI, you need to go to the DNBTUI main method 
and document/undocument the indicated lines with possible players, the comment is present in appropriate place.
If you want to use AI on the server, then after your opponents move you should press enter, after that the AI will be able to continue playing the game

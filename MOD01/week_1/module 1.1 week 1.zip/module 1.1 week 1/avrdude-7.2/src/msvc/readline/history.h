//
// history.h
// Copyright (C) 2022 Marius Greuel
// SPDX-License-Identifier: GPL-2.0-or-later
//

#pragma once

#ifdef __cplusplus
extern "C" {
#endif
    
void add_history(const char* string);

#ifdef __cplusplus
}
#endif
